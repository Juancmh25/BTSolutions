﻿using BTS.Travel.Inventory.Core.Entities;
using BTS.Travel.Inventory.Core.Interfaces;
using BTS.Travel.Inventory.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace BTS.Travel.Inventory.Infrastructure.Repositories
{
    public class EditorialRepository : IEditorialRepository
    {
        private readonly TravelInventoryContext _context;

        public EditorialRepository(TravelInventoryContext context)
        {
            _context = context;
        }

        public async Task<Editorial> GetEditorial(int id)
        {
            var editorials = await _context.Editorials.FirstOrDefaultAsync(x => x.Id == id);
            return editorials;
        }
    }
}
