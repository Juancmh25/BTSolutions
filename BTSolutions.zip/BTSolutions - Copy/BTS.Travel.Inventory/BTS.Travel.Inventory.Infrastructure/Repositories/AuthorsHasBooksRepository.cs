﻿using BTS.Travel.Inventory.Core.Entities;
using BTS.Travel.Inventory.Core.Interfaces;
using BTS.Travel.Inventory.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BTS.Travel.Inventory.Infrastructure.Repositories
{
    public class AuthorsHasBooksRepository : IAuthorsHasBooksRepository
    {
        private readonly TravelInventoryContext _context;

        public AuthorsHasBooksRepository(TravelInventoryContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<AuthorsHasBooks>> GetAuthorsByBoogId(int bookIsbn)
        {
            var authorsHasBooks = await _context.AuthorsHasBooks.ToListAsync();
            var authorsHasBooksList = authorsHasBooks.FindAll(x => x.BooksIsbn == bookIsbn);
            return authorsHasBooksList;
        }
    }
}
