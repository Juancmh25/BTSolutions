﻿using BTS.Travel.Inventory.Core.Entities;
using BTS.Travel.Inventory.Core.Interfaces;
using BTS.Travel.Inventory.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace BTS.Travel.Inventory.Infrastructure.Repositories
{
    public class AuthorRepository : IAuthorRepository
    {
        private readonly TravelInventoryContext _context;

        public AuthorRepository(TravelInventoryContext context)
        {
            _context = context;
        }

        public async Task<Author> GetAuthor(int id)
        {
            var editorials = await _context.Authors.FirstOrDefaultAsync(x => x.Id == id);
            return editorials;
        }
    }
}
