﻿using BTS.Travel.Inventory.Core.Entities;
using BTS.Travel.Inventory.Core.Interfaces;
using BTS.Travel.Inventory.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BTS.Travel.Inventory.Infrastructure.Repositories
{
    public class BookRepository : IBookRepository
    {
        private readonly TravelInventoryContext _context;

        public BookRepository(TravelInventoryContext context)
        {
            _context = context;
        }
    
        public async Task<IEnumerable<Book>> GetBooks()
        {
            var books = await _context.Books.ToListAsync();
            return books;
        }

        public async Task<Book> GetBook(int id)
        {
            var books = await _context.Books.FirstOrDefaultAsync(x => x.Isbn == id);
            return books;
        }

        public async Task InsertBook(Book book)
        {
            _context.Books.Add(book);
            await _context.SaveChangesAsync();
        }
    }
}
