﻿using BTS.Travel.Inventory.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BTS.Travel.Inventory.Infrastructure.Data.Configurations
{
    public class AuthorshasBooksConfiguration : IEntityTypeConfiguration<AuthorsHasBooks>
    {
        public void Configure(EntityTypeBuilder<AuthorsHasBooks> builder)
        {
            builder.HasKey(e => new { e.AuthorsId, e.BooksIsbn })
                    .IsClustered(false);

            builder.ToTable("autores_has_libros");

            builder.Property(e => e.AuthorsId).HasColumnName("autores_id");

            builder.Property(e => e.BooksIsbn).HasColumnName("libros_ISBN");

            builder.HasOne(d => d.Authors)
                .WithMany(p => p.AuthorsHasBooks)
                .HasForeignKey(d => d.AuthorsId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_autores_has_libros_autores");

            builder.HasOne(d => d.Books)
                .WithMany(p => p.AuthorsHasBooks)
                .HasForeignKey(d => d.BooksIsbn)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_autores_has_libros_libros");
        }
    }
}
