﻿using BTS.Travel.Inventory.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BTS.Travel.Inventory.Infrastructure.Data.Configurations
{
    public class BookConfiguration : IEntityTypeConfiguration<Book>
    {
        public void Configure(EntityTypeBuilder<Book> builder)
        {
            builder.HasKey(e => e.Isbn)
                    .HasName("PK_ISBN");

            builder.ToTable("libros");

            builder.Property(e => e.Isbn)
                .ValueGeneratedNever()
                .HasColumnName("ISBN");

            builder.Property(e => e.EditorialsId).HasColumnName("editoriales_id");

            builder.Property(e => e.NumberPages)
                .IsRequired()
                .HasMaxLength(45)
                .IsUnicode(false)
                .HasColumnName("n_paginas");

            builder.Property(e => e.Synopsis)
                .IsRequired()
                .HasColumnType("text")
                .HasColumnName("sinopsis");

            builder.Property(e => e.Title)
                .IsRequired()
                .HasMaxLength(45)
                .IsUnicode(false)
                .HasColumnName("titulo");

            builder.HasOne(d => d.Editorials)
                .WithMany(p => p.Books)
                .HasForeignKey(d => d.EditorialsId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_libros_editoriales");
        }
    }
}
