﻿using BTS.Travel.Inventory.Core.Entities;
using BTS.Travel.Inventory.Infrastructure.Data.Configurations;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace BTS.Travel.Inventory.Infrastructure.Data
{
    public partial class TravelInventoryContext : DbContext
    {
        public TravelInventoryContext()
        {
        }

        public TravelInventoryContext(DbContextOptions<TravelInventoryContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Author> Authors { get; set; }
        public virtual DbSet<AuthorsHasBooks> AuthorsHasBooks { get; set; }
        public virtual DbSet<Editorial> Editorials { get; set; }
        public virtual DbSet<Book> Books { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new AuthorConfiguration());
            modelBuilder.ApplyConfiguration(new AuthorshasBooksConfiguration());
            modelBuilder.ApplyConfiguration(new EditorialConfiguration());
            modelBuilder.ApplyConfiguration(new BookConfiguration());
        }
    }
}
