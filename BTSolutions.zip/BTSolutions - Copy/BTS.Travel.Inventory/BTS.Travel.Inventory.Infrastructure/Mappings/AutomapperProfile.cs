﻿using AutoMapper;
using BTS.Travel.Inventory.Core.DTOs;
using BTS.Travel.Inventory.Core.Entities;

namespace BTS.Travel.Inventory.Infrastructure.Mappings
{
    public class AutomapperProfile : Profile
    {
        public AutomapperProfile()
        {
            CreateMap<Book, BookDto>();
            CreateMap<BookDto, Book>();
            CreateMap<Editorial, EditorialDto>();
            CreateMap<EditorialDto, Editorial>();
            CreateMap<Author, AuthorDto>();
            CreateMap<AuthorDto, Author>();
        }
    }
}
