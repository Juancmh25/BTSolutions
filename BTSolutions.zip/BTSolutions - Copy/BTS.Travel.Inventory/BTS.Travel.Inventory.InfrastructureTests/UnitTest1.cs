using System;
using Xunit;

namespace BTS.Travel.Inventory.InfrastructureTests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
