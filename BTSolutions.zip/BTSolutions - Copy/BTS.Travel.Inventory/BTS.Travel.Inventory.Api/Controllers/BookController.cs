﻿using AutoMapper;
using BTS.Travel.Inventory.Core.DTOs;
using BTS.Travel.Inventory.Core.Entities;
using BTS.Travel.Inventory.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BTS.Travel.Inventory.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly IBookRepository _bookRepository;
        private readonly IMapper _mapper;

        public BookController(IBookRepository bookRepository, IMapper mapper)
        {
            _bookRepository = bookRepository;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<IActionResult> GetBooks()
        {
            var books = await _bookRepository.GetBooks();
            var booksDto = _mapper.Map<IEnumerable<BookDto>>(books);
            return Ok(booksDto);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetBooks(int id)
        {
            var books = await _bookRepository.GetBook(id);
            var booksDto = _mapper.Map<BookDto>(books);
            return Ok(booksDto);
        }

        [HttpPost]
        public async Task<IActionResult> InsertBook(BookDto bookDto)
        {
            var book = _mapper.Map<Book>(bookDto);
            await _bookRepository.InsertBook(book);
            return Ok(bookDto);
        }
    }
}
