﻿using AutoMapper;
using BTS.Travel.Inventory.Core.DTOs;
using BTS.Travel.Inventory.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace BTS.Travel.Inventory.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthorController : ControllerBase
    {
        private readonly IAuthorRepository _authorRepository;
        private readonly IMapper _mapper;

        public AuthorController(IAuthorRepository authorRepository, IMapper mapper)
        {
            _authorRepository = authorRepository;
            _mapper = mapper;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetEditorial(int id)
        {
            var authors = await _authorRepository.GetAuthor(id);
            var authorDto = _mapper.Map<AuthorDto>(authors);
            return Ok(authorDto);
        }
    }
}
