﻿using AutoMapper;
using BTS.Travel.Inventory.Core.DTOs;
using BTS.Travel.Inventory.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace BTS.Travel.Inventory.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EditorialController : ControllerBase
    {
        private readonly IEditorialRepository _editorialRepository;
        private readonly IMapper _mapper;

        public EditorialController(IEditorialRepository editorialRepository, IMapper mapper)
        {
            _editorialRepository = editorialRepository;
            _mapper = mapper;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetEditorial(int id)
        {
            var editorials = await _editorialRepository.GetEditorial(id);
            var editorialDto = _mapper.Map<EditorialDto>(editorials);
            return Ok(editorialDto);
        }
    }
}
