﻿namespace BTS.Travel.Inventory.Core.DTOs
{
    public class AuthorDto
    {
        public string Name { get; set; }
        public string LastName { get; set; }
    }
}
