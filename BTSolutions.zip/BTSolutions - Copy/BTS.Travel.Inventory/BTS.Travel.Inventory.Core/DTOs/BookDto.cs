﻿namespace BTS.Travel.Inventory.Core.DTOs
{
    public class BookDto
    {
        public int Isbn { get; set; }
        public int EditorialsId { get; set; }
        public string Title { get; set; }
        public string Synopsis { get; set; }
        public string NumberPages { get; set; }
    }
}
