﻿namespace BTS.Travel.Inventory.Core.DTOs
{
    public class BookDetailsDto
    {
        public int Isbn { get; set; }
        public string Title { get; set; }
        public virtual EditorialDto Editorials { get; set; }
        public virtual AuthorDto Authors { get; set; }
    }
}
