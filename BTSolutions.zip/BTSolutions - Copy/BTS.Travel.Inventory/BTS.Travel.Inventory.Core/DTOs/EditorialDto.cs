﻿namespace BTS.Travel.Inventory.Core.DTOs
{
    public class EditorialDto
    {
        public string Name { get; set; }
        public string Headquarters { get; set; }
    }
}
