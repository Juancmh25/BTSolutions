﻿using System.Collections.Generic;

#nullable disable

namespace BTS.Travel.Inventory.Core.Entities
{
    public partial class Author
    {
        public Author()
        {
            AuthorsHasBooks = new HashSet<AuthorsHasBooks>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string LastName { get; set; }

        public virtual ICollection<AuthorsHasBooks> AuthorsHasBooks { get; set; }
    }
}
