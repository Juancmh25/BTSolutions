﻿using System.Collections.Generic;

#nullable disable

namespace BTS.Travel.Inventory.Core.Entities
{
    public partial class Book
    {
        public Book()
        {
            AuthorsHasBooks = new HashSet<AuthorsHasBooks>();
        }

        public int Isbn { get; set; }
        public int EditorialsId { get; set; }
        public string Title { get; set; }
        public string Synopsis { get; set; }
        public string NumberPages { get; set; }

        public virtual Editorial Editorials { get; set; }
        public virtual ICollection<AuthorsHasBooks> AuthorsHasBooks { get; set; }
    }
}
