﻿#nullable disable

namespace BTS.Travel.Inventory.Core.Entities
{
    public partial class AuthorsHasBooks
    {
        public int AuthorsId { get; set; }
        public int BooksIsbn { get; set; }

        public virtual Author Authors { get; set; }
        public virtual Book Books { get; set; }
    }
}
