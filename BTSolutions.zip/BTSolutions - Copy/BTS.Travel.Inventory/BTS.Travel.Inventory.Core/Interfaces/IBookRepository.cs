﻿using BTS.Travel.Inventory.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BTS.Travel.Inventory.Core.Interfaces
{
    public interface IBookRepository
    {
        Task<IEnumerable<Book>> GetBooks();
        Task<Book> GetBook(int id);
        Task InsertBook(Book book);
    }
}
