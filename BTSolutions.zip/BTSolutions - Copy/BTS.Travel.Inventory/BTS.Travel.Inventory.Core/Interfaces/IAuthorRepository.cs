﻿using BTS.Travel.Inventory.Core.Entities;
using System.Threading.Tasks;

namespace BTS.Travel.Inventory.Core.Interfaces
{
    public interface IAuthorRepository
    {
        Task<Author> GetAuthor(int id);
    }
}
