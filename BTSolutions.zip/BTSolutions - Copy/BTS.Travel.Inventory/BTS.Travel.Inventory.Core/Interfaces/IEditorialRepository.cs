﻿using BTS.Travel.Inventory.Core.Entities;
using System.Threading.Tasks;

namespace BTS.Travel.Inventory.Core.Interfaces
{
    public interface IEditorialRepository
    {
        Task<Editorial> GetEditorial(int id);
    }
}
