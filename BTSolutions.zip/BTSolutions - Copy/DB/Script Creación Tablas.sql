﻿USE [TravelInventory]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[libros](
	[ISBN] [int] NOT NULL,
	[editoriales_id] [int] NOT NULL,
	[titulo] [varchar] (45) NOT NULL,
	[sinopsis] [text] NOT NULL,
	[n_paginas] [varchar] (45) NOT NULL,
 CONSTRAINT [PK_ISBN] PRIMARY KEY CLUSTERED 
(
	[ISBN] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[editoriales](
	[id] [int] NOT NULL,
	[nombre] [varchar] (45) NOT NULL,
	[sede] [varchar] (45) NOT NULL,
 CONSTRAINT [PK_Editoriales] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[autores](
	[id] [int] NOT NULL,
	[nombre] [varchar](45) NOT NULL,
	[apellidos] [varchar](45) NOT NULL,
 CONSTRAINT [PK_Id] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[autores_has_libros](
	[autores_id] [int] NOT NULL,
	[libros_ISBN] [int] NOT NULL,
 CONSTRAINT [PK_autores_has_libros] PRIMARY KEY NONCLUSTERED 
(
	[autores_id], [libros_ISBN] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[libros]  WITH NOCHECK ADD  CONSTRAINT [FK_libros_editoriales] FOREIGN KEY([editoriales_id])
REFERENCES [dbo].[editoriales] ([id])
GO
ALTER TABLE [dbo].[libros] CHECK CONSTRAINT [FK_libros_editoriales]
GO
ALTER TABLE [dbo].[autores_has_libros]  WITH NOCHECK ADD  CONSTRAINT [FK_autores_has_libros_autores] FOREIGN KEY([autores_id])
REFERENCES [dbo].[autores] ([id])
GO
ALTER TABLE [dbo].[autores_has_libros] CHECK CONSTRAINT [FK_autores_has_libros_autores]
GO
ALTER TABLE [dbo].[autores_has_libros]  WITH NOCHECK ADD  CONSTRAINT [FK_autores_has_libros_libros] FOREIGN KEY([libros_ISBN])
REFERENCES [dbo].[libros] ([ISBN])
GO
ALTER TABLE [dbo].[autores_has_libros] CHECK CONSTRAINT [FK_autores_has_libros_libros]
GO

INSERT INTO [dbo].[autores] ([id],[nombre],[apellidos])VALUES(1,'Arnold','Lobel')
GO
INSERT INTO [dbo].[autores]([id],[nombre],[apellidos])VALUES(2,'Pablo','Albo')
GO
INSERT INTO [dbo].[autores]([id],[nombre],[apellidos])VALUES(3,'Jeanne','Willis')
GO
INSERT INTO [dbo].[autores]([id],[nombre],[apellidos])VALUES(4,'Olivier','Tallec')
GO

INSERT INTO [dbo].[editoriales]([id],[nombre],[sede])VALUES(1,'Kalandraka','España')
GO
INSERT INTO [dbo].[editoriales]([id],[nombre],[sede])VALUES(2,'Narval editores','España')
GO
INSERT INTO [dbo].[editoriales]([id],[nombre],[sede])VALUES(3,'Libros del Zorro Rojo','Argentina')
GO
INSERT INTO [dbo].[editoriales]([id],[nombre],[sede])VALUES(4,'Adriana Hidalgo editora','España')
GO

INSERT INTO [dbo].[libros]([ISBN],[editoriales_id],[titulo],[sinopsis],[n_paginas])VALUES(1234567891,1,'Saltamontes va de viaje','Entre la treintena de cuentos que escribió e ilustró el estadounidense Arnold Lobel —su producción para obras ajenas fue incluso mayor—, figura esta travesía cargada de fábulas que se recupera cada cierto tiempo. En el camino que inicia Saltamontes se cruzan escarabajos que ensalzan el seguidismo y marginan la disidencia, gusanos adaptativos ante la adversidad, moscas con trastorno obsesivo o mariposas de rutinas intransigentes. Con todos ellos compartirá experiencias el protagonista, un insecto curioso, tolerante, amante de las sorpresas diarias y de los regalos de la naturaleza.',68)
GO
INSERT INTO [dbo].[libros]([ISBN],[editoriales_id],[titulo],[sinopsis],[n_paginas])VALUES(1234567892,2,'La merienda del parque','Aunque el título remite a escenas bucólicas cursis y recargadas en la campiña, lo cierto es que este libro destaca por lo contrario, busca ser depurado, sencillo y naif. Pablo Albo y Cecilia Moreno se valen de potentes colores e imágenes geométricas y modernas que recuerdan a las señales de tráfico para contar una historia protagonizada por un parque que tiene la costumbre de merendar. Una excusa que permitirá descubrir una fauna sorprendente que habita entre los humanos en la ciudad. El original volumen está también traducido al euskera, gallego y catalán.',44)
GO
INSERT INTO [dbo].[libros]([ISBN],[editoriales_id],[titulo],[sinopsis],[n_paginas])VALUES(1234567893,3,'Empanada de mamut','Un grupo de cavernícolas hartos del veganismo forzoso del guiso de cardos y un mamut vacilón protagonizan el nuevo álbum conjunto de la escritora Jeanne Willis y el ilustrador Tony Ross. El hambriento Gor movilizará a todos sus amigos para cazar al paquidermo. Pero Gor no es el único que tiene amigos. Dibujado con el inconfundible estilo de Ross —que tiene ya más de un millar de obras a cuestas, incluida la popular serie Pablo Diablo (Horrid Henry, en inglés), y acaba de ser elegido el ilustrador más solicitado en las bibliotecas británicas con un millón de préstamos en 2016.',36)
GO
INSERT INTO [dbo].[libros]([ISBN],[editoriales_id],[titulo],[sinopsis],[n_paginas])VALUES(1234567894,4,'Waterloo y Trafalgar','Dos colores. Dos militares. Dos rutinas. Dos trincheras minimalistas separadas por un río de hierba. Dos derrotas napoleónicas, Waterloo y Trafalgar, sirven al ilustrador francés Olivier Tallec para ahondar con ironía en la sinrazón de la guerra. Un soldado naranja y un soldado azul se vigilan mutuamente. Uno es romántico y otro pragmático. Ambos tienen más cosas en común de las que los separan: el frío, el temor, el aburrimiento, la agresividad. Con un dibujo sencillo, Tallec ha concebido uno de esos álbumes mudos y limpios, que evidencia lo innecesarias que son a veces las palabras.',36)
GO


INSERT INTO [dbo].[autores_has_libros]([autores_id],[libros_ISBN])VALUES(1,1234567891)
GO
INSERT INTO [dbo].[autores_has_libros]([autores_id],[libros_ISBN])VALUES(2,1234567892)
GO
INSERT INTO [dbo].[autores_has_libros]([autores_id],[libros_ISBN])VALUES(3,1234567893)
GO
INSERT INTO [dbo].[autores_has_libros]([autores_id],[libros_ISBN])VALUES(4,1234567894)
GO